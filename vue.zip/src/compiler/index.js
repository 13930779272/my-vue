
const ncname = `[a-zA-Z_][\\-\\.0-9_a-zA-Z]*`; // 匹配标签名的 aa-xxx
const qnameCapture = `((?:${ncname}\\:)?${ncname})`; // 命名空间标签 aa:aa-xxx
const startTagOpen = new RegExp(`^<${qnameCapture}`); // 标签开头的正则 捕获的内容是标签名 索引第一个 [1]
const endTag = new RegExp(`^<\\/${qnameCapture}[^>]*>`); // 匹配标签结尾的 </div> 索引第一个 [1]
const attribute = /^\s*([^\s"'<>\/=]+)(?:\s*(=)\s*(?:"([^"]*)"+|'([^']*)'+|([^\s"'=<>`]+)))?/; // 匹配属性的 a=xxx a="xxx" a='xxx'
const startTagClose = /^\s*(\/?)>/; // 匹配标签结束的  > />
const defaultTagRE = /\{\{((?:.|\r?\n)+?)\}\}/g  // 匹配{{ xxx }}

// 解析html,会编译成一个对象非常像虚拟DOM但是不是虚拟DOM
function parserHTML(html) {

  // 删除匹配到的字符
  function advance(len) {
    html = html.substring(len)
  };
  // 处理开始标签
  function parseStartTag() {
    const start = html.match(startTagOpen);
    const match = {
      tagName: start[1],
      attrs: []
    }
    advance(start[0].length);
    let end;
    let arr;
    // debugger
    // 有属性并且没有匹配到开始标签的结束（> />）就继续循环直到匹配到开始标签的结束（> />）为止
    while(!(end = html.match(startTagClose)) && (arr = html.match(attribute))) {
      // 在match里面添加属性
      match.attrs.push({
        name: arr[1],
        value: arr[3] || arr[4] || arr[5]
      });
      advance(arr[0].length)
    }
    if(end) {
      advance(end[0].length)
    }
    // return match;
    console.log(match, html)
  };
  // 不停的截取模板，直到模板全部解析完毕
  while(html) {
    // 解析标签和文本 <
    let index = html.indexOf('<');
    if(index === 0) {
      // 解析开始标签并且把属性也解析出来
      const startTagMatch = parseStartTag();
      console.log(startTagMatch);
      // 开始标签
      if(startTagMatch) {
        continue;
      }
      // < 也有可能是结束标签
      if(html.match(endTag)) {
        continue;
      }
      break;
    }
  }
}

export function compilerToFunction(template) {
  // console.log(template);
  // 第一步将模板变成ast语法树
  let ast = parserHTML(template)
}